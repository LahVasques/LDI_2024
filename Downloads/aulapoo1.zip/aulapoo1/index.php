<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Inicio</title>
    <?php include_once "control/pessoa.php" ?>
</head>
<body>
    <h1>Cadastro de Clientes</h1>
    <?php
       $cliente = new Pessoa;
       echo "Nome: " . $cliente->nome . "</br";
       echo "Idade: " . $cliente->idade . "</br>";
       echo "Apelido: " . $cliente->apelido . "</br>";
       echo "Sexo: " . $cliente->sexo . "</br>";
    ?> 
    <h1>Cadastro de Amigo</h1>
    <?php
      $amigo = new Pessoa;
      echo "Nome: " . $amigo->nome = "Beatriz </br>" ;
      echo "Apelido: " . $amigo->apelido = "Bea </br>" ;
      echo "Sexo: " . $amigo->sexo = "Feminino </br>" ;
      echo "Idade: " . $amigo->idade = 17 ;

      $amigo->exibirdado();
    ?>
</body>
</html>