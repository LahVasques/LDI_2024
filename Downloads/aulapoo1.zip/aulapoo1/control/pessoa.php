<?php
    class Pessoa{
        public $nome = "Graziella";
        public $idade = 18;
        public $apelido = "aluno";
        public $sexo = "Feminino";
    //metodo publico para exibir um dado
    public function exibirdado(){
        echo "Nome: " . $this->nome = "Laiss Varques";
       }    

    }

?>