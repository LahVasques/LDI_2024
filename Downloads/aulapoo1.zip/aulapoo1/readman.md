Questões
1- O que é programação Orientado ao objeto?
R: Trata-se de um modelo de programação que estrutura o código em torno de objetos, que simbolizam entidades da realidade.

2- O que é instanciar?
R: É um processso de gerar um objeto na memoria do computador a partir de uma classe 

3- O que é um objeto?
R: Um componente que simboliza uma entidade do universo real.

4- O que é uma classe?
R: classse consiste em um conjunto de objetos com as caracteristicas em comum

5-Explique sobre o POO:
R: POO é a Promagração Orientada ao Objeto

6- Explique sobre ->;
R: A seta representa um sinal que sinaliza a atribuição de dados a uma variável.

7- Explique sobre $this->nome?
R: O $this->nome é utilizado para fazer referência ao objeto.

8-Explique sobre o new;
R: É usado para criar um  novo objeto

9- Explique sobre os quatro pilares da POO;
Existe 4 Pilares: Herança, Polimorfismo, Abstração, Encapsulamento 
Herança é transmitida de "pai" para "filho" na forma escrita do código. 
Polimorfismo é um objeto assume a aparência de outro em certas situações, de acordo com as escolhas do próprio desenvolvedor que está conduzindo o projeto.
Abstração é um pilar que o objeto é representado de maneira abstrata, embora muitos vejam a abstração como uma fusão dos conceitos de encapsulamento e polimorfismo.
Encapsulamento oculta pormenores da execução do código, de acordo com as necessidades de cada projeto.
